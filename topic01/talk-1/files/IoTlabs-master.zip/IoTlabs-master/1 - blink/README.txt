## blink
This example is what one might call the hello world example for Arduino sketches. We wire up the experiment as shown in the diagram. 

Next upload the Sketch code in the Sketch directory associated with this experiment.

When working, this will blink on for a second and then off for a second.