## Thermistor
We wire up the experiment as shown in the diagram. And upload the sketch code associated with this experiment.

The thermistor is an electrical resistor whose resistance is greatly reduced by heating, used for measurement and control see the image.

Open up the serial monitor to view the resitance value being read from the thermistor.