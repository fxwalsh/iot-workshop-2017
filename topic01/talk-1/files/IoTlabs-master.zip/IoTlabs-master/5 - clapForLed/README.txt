## clap4Led
We wire up the experiment as shown in the diagram. And upload the sketch code associated with this experiment.

Pay close attention to the image diagram explaining the polarity of the microphone module!

Making sound or clapping, will activate the LED.