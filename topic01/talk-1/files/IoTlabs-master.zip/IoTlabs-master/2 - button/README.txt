## Button
We wire up the experiment as shown in the diagram. And upload the sketch code associated with this experiment.

Pay close attention to the layout of the button, see the diagram which explains the layout of the button internally.

The LED will light when the button is pressed.