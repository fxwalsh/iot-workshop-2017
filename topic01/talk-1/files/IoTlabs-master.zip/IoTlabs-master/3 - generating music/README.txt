## Generating music
We wire up the experiment as shown in the diagram. And upload the sketch code associated with this experiment.

As soon as the Arduino boots it should play a series of musical notes and then stop. For more information see the online reference page for the functions used in this experiment here: https://www.arduino.cc/en/Reference/Tone